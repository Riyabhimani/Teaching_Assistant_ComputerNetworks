const express = require('express');
require('dotenv').config()
const app = express()
const PORT = process.env.PORT

app.get('/',(req,res)=>{
    return res.send(`Server is Running on PORT ${PORT}`)
})
app.listen(PORT,()=>{
    console.log(`Srever Run AT PORT ${PORT}`)
})