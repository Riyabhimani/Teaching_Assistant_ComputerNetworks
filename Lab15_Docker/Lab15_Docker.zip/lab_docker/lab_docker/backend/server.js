const express = require("express");
const mysql = require("mysql2");
const os = require("os");

const app = express();
const PORT = process.env.PORT || 5000;

const DB_HOST = process.env.DB_HOST || "database";
const DB_USER = process.env.DB_USER || "labuser";
const DB_PASSWORD = process.env.DB_PASSWORD || "labpassword";
const DB_NAME = process.env.DB_NAME || "labdb";

function getConnection() {
  return mysql.createConnection({
    host: DB_HOST,
    user: DB_USER,
    password: DB_PASSWORD,
    database: DB_NAME,
  });
}

app.get("/api/health", (req, res) => {
  res.json({
    status: "backend is up",
    container: os.hostname(),
    dbHostConfigured: DB_HOST,
  });
});

app.get("/api/students", (req, res) => {
  const conn = getConnection();
  conn.connect((err) => {
    if (err) {
      res.status(500).json({
        error: "Could not connect to database",
        details: err.message,
        dbHostConfigured: DB_HOST,
      });
      return;
    }
    conn.query("SELECT id, name, course FROM students", (qErr, rows) => {
      conn.end();
      if (qErr) {
        res.status(500).json({ error: "Query failed", details: qErr.message });
        return;
      }
      res.json({
        servedBy: os.hostname(),
        dbHost: DB_HOST,
        students: rows,
      });
    });
  });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Backend container [${os.hostname()}] listening on port ${PORT}`);
  console.log(`Configured DB_HOST=${DB_HOST}`);
});
