CREATE DATABASE IF NOT EXISTS labdb;
USE labdb;

CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    course VARCHAR(100) NOT NULL
);

INSERT INTO students (name, course) VALUES
    ('Aarav Shah', 'Computer Networks'),
    ('Diya Patel', 'Operating Systems'),
    ('Kabir Mehta', 'Cloud Computing');
